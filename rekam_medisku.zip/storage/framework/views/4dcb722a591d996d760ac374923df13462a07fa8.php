<!DOCTYPE html>

<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>

  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Sistem Pengukuran Literasi | SMA YPPI II</title>

    <meta name="description" content="" />

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.ico')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/boxicons.css')); ?>" />

    <!-- font awesome icons v6 -->
    <link href="<?php echo e(asset('assets/fontawesome-free-6.2.0-web/css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/fontawesome-free-6.2.0-web/css/brands.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/fontawesome-free-6.2.0-web/css/solid.css')); ?>" rel="stylesheet">

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />

    
    <link rel="stylesheet" href="<?php echo e(asset('/css/css_sendiri.css')); ?>">

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    
    <script src="<?php echo e(asset('plugins/iziToast/iziToast.js')); ?>"></script>
    
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('assets\datatable-1.12.1\jquery.dataTables.min.css')); ?>">

    
    <script src="<?php echo e(asset('assets/sweetalert/sweetalert2_11.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/iziToast/iziToast.css')); ?>">

  </head>

  <body>

    <!-- Layout wrapper -->
    <?php if(auth()->check()): ?>
      <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
          <!-- Menu -->
          <?php if(auth()->user()->hasRole('admin')): ?>            
            <?php echo $__env->make('partials.sidebar.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
          <?php endif; ?>
          <?php if(auth()->user()->hasRole('guru')): ?>            
            <?php echo $__env->make('partials.sidebar.guru_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
          <?php endif; ?>
          <?php if(auth()->user()->hasRole('siswa')): ?>            
            <?php echo $__env->make('partials.sidebar.siswa_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
          <?php endif; ?>
          <!-- / Menu -->

          <!-- Layout container -->
          <div class="layout-page">
            <!-- Navbar -->

            <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- / Navbar -->

            
            

            <?php echo $__env->yieldContent('container'); ?>

            
            <?php echo $__env->make('partials.change_password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content wrapper -->
          </div>
          <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
      </div>
    <?php else: ?> 
      <?php echo $__env->yieldContent('container'); ?>
    <?php endif; ?>
    <!-- / Layout wrapper -->

    <!-- Vendors JS -->
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <!-- Page JS -->
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>

    
    <script src="<?php echo e(asset('assets\datatable-1.12.1\jquery.dataTables.min.js')); ?>"></script>


    
    <script>
      $(document).ready(function(){
        $('.datatable').dataTable();
      });
    </script>

    
    <?php if(session()->has('success')): ?>
      <script>
        iziToast.success({
          title: "<?php echo e(session('success')); ?>",
          position: 'topCenter'
        });
      </script>
    <?php elseif(session()->has('danger')): ?>
      <script>
        iziToast.error({
          title: "<?php echo e(session('danger')); ?>",
          position: 'topCenter'
        });
      </script>
    <?php endif; ?>
    
    <?php if($errors->any()): ?>
      <?php if($errors->has('not_allowed')): ?>
        <script>
          Swal.fire({
            icon: 'error',
            title: 'Anda tidak memiliki akses',
          })
        </script>
      <?php else: ?>
        <script>
          iziToast.error({
            title: "<?php echo implode('<br>', $errors->all('- :message')); ?>",
            position: 'topCenter'
          });
        </script>
      <?php endif; ?>
    <?php endif; ?>

    
    
    <script>
      $(document).ready(function () {
         $.ajaxSetup({
           headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
         });
       });
   </script>

   
   <script>
     $('form').on('submit', function(event) {
       if( ! $(this).hasClass('dont_disabled')){
         $(this).find(":submit").prop('disabled', true);
         $(this).find(":submit").html('Memproses...');
       }
       });
   </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\spl\resources\views/layouts/main_layout.blade.php ENDPATH**/ ?>