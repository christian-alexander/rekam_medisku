<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Rekam Medisku</title>
  <style>
    @page  { margin: 0cm; }

    #tabel {
      width: 26cm;
      border: 2px solid black;
      border-collapse: collapse;
      text-align: center;
    }
    #tabel td,
    #tabel th {
      border: 2px solid black;
      height:0.5cm;
      padding-right: 0.2cm;
      padding-left: 0.2cm;
      word-wrap:break-word;
    }

    body{
      padding:0.5cm;
      background-color: rgb(255, 254, 150);
      width:29cm;
      height:20cm;
      font-family:Arial, Helvetica, sans-serif;
    }
  </style>
</head>
<body>
  <div style="width:100%;text-align:left;">
    <h4 style='margin-top:0;padding-top:0;'>
      REKAM MEDISKU ( <?php echo e(($tipe_rekam_medis == "personal")? "PERSONAL" : "TENAGA KESEHATAN"); ?>

      <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
        <?php echo e(($filters['tipe_tenaga_kesehatan'] == 'all')? 'SEMUA TIPE' : (($filters['tipe_tenaga_kesehatan'] == 1)? 'DOKTER' : 'PENGOBAT TRADISIONAL')); ?>)
      <?php else: ?> 
        )
      <?php endif; ?>
      <br>
      <?php echo e(Carbon::parse($filters['awal_tanggal'])->format('d M Y')); ?> - <?php echo e(Carbon::parse($filters['akhir_tanggal'])->format('d M Y')); ?>

    </h4>
    <table>
      <tr>
        <td style='width:3cm;'>Nama Lengkap</td>
        <td style='width:6cm;'>: <?php echo e($pasien->nama); ?></td>
        <td style='width:3cm;'>Jenis Kelamin</td>
        <td style='width:6cm;'>: <?php echo e(($pasien->jenis_kelamin == 1)? 'Laki laki' : 'Perempuan'); ?></td>
      </tr>
      <tr>
        <td style='width:3cm;'>Tanggal Lahir</td>
        <td style='width:6cm;'>: <?php echo e(Carbon::parse($pasien->tanggal_lahir)->format('d M Y')); ?> ( <?php echo e(str_replace("yang lalu","",Carbon::parse($pasien->tanggal_lahir)->diffForHumans())); ?>)</td>
        <td style='width:3cm;'>No. HP</td>
        <td style='width:6cm;'>: <?php echo e($pasien->no_hp); ?></td>
      </tr>
    </table>
  </div>
  <table id='tabel' style='margin-top:0.5cm;'>
    <thead>
      <tr>
        <th style='width:3cm;'>Tanggal</th>
        <?php if($tipe_rekam_medis == 'tenaga_kesehatan'): ?>        
          <th style='width:3cm;'>Tenaga Kesehatan</th>
          <th style='width:8cm;'>Anamnesa</th>
          <th style='width:6cm;'>Diagnosis</th>
          <th style='width:6cm;'>Terapi</th>
        <?php else: ?>
          <th style='width:10cm;'>Anamnesa</th>
          <th style='width:7cm;'>Diagnosis</th>
          <th style='width:7cm;'>Terapi</th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody>
      <?php if(count($rekam_medises) == 0): ?>
        <tr>
          <td colspan="<?php echo e(($tipe_rekam_medis == "personal")? '3' : '4'); ?>">Belum ada data</td>
        </tr>
      <?php else: ?>
        <?php $__currentLoopData = $rekam_medises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekam_medis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
          <tr>
            <td><?php echo e(Carbon::parse($rekam_medis->tanggal)->format('d M Y')); ?></td>
            <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
              <td><?php echo e($rekam_medis->tenaga_kesehatan->nama); ?></td>
            <?php endif; ?>
            <td style="text-align:justify;"><?php echo e($rekam_medis->anamnesa); ?></td>
            <td style="text-align:justify;"><?php echo e($rekam_medis->diagnosis); ?></td>
            <td style="text-align:justify;"><?php echo e($rekam_medis->terapi); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/rekam_medis/pdf.blade.php ENDPATH**/ ?>