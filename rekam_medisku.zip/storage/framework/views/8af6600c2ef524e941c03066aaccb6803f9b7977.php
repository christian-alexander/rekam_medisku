

<?php $__env->startSection('container'); ?>

<div class="container mt-3">
    
  <div class="card mb-4">
    <div class="card-body">
      
      <h4 style='text-align:center;'>Daftar Instalasi</h4> 
      <button onclick="tambah()" class='btn btn-success' style='margin-bottom:20px;'>Tambah</button>
      <div style='overflow:auto;'>
        <table class='table table-striped datatable'>
          <thead>
            <tr>
              <th style='width:20px;'>No</th>
              <th style='text-align:center;'>Lokasi</th>
              <th style='text-align:center;'>Nama Instalasi</th>
              <th style='text-align:center;'>Tipe</th>
              <th style='text-align:center;'>Edit</th>
              <th style='text-align:center;'>Hapus</th>
            </tr>
          </thead>
          <tbody>

            <tr>
              <td style="text-align:right;">1</td>

              <td style="text-align:center;">
                Jl. Kesehatan No. 1
                <br>
                Surabaya, Jawa Timur
              </td>

              <td style='text-align:center;'>
                Rumah Sakit Eka Husada
              </td>

              <td style='text-align:center;'>
                Faskes Modern
              </td>

              <td style='text-align:center;'>
                <button id='btn_edit' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='edit(1)'>
                  <i class='fa fa-edit' style='color:#3c8dbc;'></i>
                </button>
              </td>
              
              <td style='text-align:center;'>
                <button id='btn_hapus' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='hapus(1)'>
                  <i class='fa fa-trash' style='color:#3c8dbc;'></i>
                </button>
              </td>

            </tr>

            <tr>
              <td style="text-align:right;">2</td>

              <td style="text-align:center;">
                Jl. Kesehatan No. 12
                <br>
                Surabaya, Jawa Timur
              </td>

              <td style='text-align:center;'>
                Klinik Utama Husada
              </td>

              <td style='text-align:center;'>
                Faskes Modern
              </td>

              <td style='text-align:center;'>
                <button id='btn_edit' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='edit(1)'>
                  <i class='fa fa-edit' style='color:#3c8dbc;'></i>
                </button>
              </td>
              
              <td style='text-align:center;'>
                <button id='btn_hapus' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='hapus(1)'>
                  <i class='fa fa-trash' style='color:#3c8dbc;'></i>
                </button>
              </td>

            </tr>

            <tr>
              <td style="text-align:right;">3</td>

              <td style="text-align:center;">
                Jl. Kesehatan No. 98
                <br>
                Surabaya, Jawa Timur
              </td>

              <td style='text-align:center;'>
                Sangkal Putung Joss
              </td>

              <td style='text-align:center;'>
                Faskes Tradisional
              </td>

              <td style='text-align:center;'>
                <button id='btn_edit' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='edit(1)'>
                  <i class='fa fa-edit' style='color:#3c8dbc;'></i>
                </button>
              </td>
              
              <td style='text-align:center;'>
                <button id='btn_hapus' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='hapus(1)'>
                  <i class='fa fa-trash' style='color:#3c8dbc;'></i>
                </button>
              </td>

            </tr>

          </tbody>
        </table>
      </div>
  
    </div>
  
  </div>
      

</div>

    

<div class="modal" tabindex="-1" id='modal_tambah'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Faskes</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="#" method='POST' id='form_edit'>
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>

          <div class='mb-3'>
            <label class='form-label' for="nama">Nama</label>
            <input type="text" class='form-control' name="nama" id="nama" placeholder="Rumah Sakit Bersahaja">
          </div>

          <div class='mb-3'>
            <label class='form-label' for="tipe_faskes">Tipe Faskes</label>
            <select class='form-control select2' name="tipe_faskes" id="tipe_faskes" style="width: 100%;">
              <option value="1">Faskes Modern</option>
              <option value="2">Faskes Tradisional</option>
            </select>
          </div>

          <div class='mb-3'>
            <label class='form-label' for="alamat">Alamat</label>
            <input type="text" class='form-control' name="alamat" id="alamat" placeholder="Jl. Kesehatan No.1 (tanpa kota dan provinsi)">
          </div>

          <div class="mb-3">
            <label class="form-label" for="provinsi">Provinsi</label>
            <input type="hidden" name="provinsi" id="provinsi_asli">
            <div class="position-relative">
              <select id="provinsi" class='form-control select2' aria-hidden="true" style='width:100%;'>
                
              </select>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label" for="kota">Kota</label>
            <input type="hidden" name="kota" id="kota_asli">
            <div class="position-relative">
              <select id="kota" class='form-control select2' tabindex="-1" aria-hidden="true" style='width:100%;'>
                
              </select>
            </div>
          </div>

          <div class="form-group" style='text-align:center;'>
            <button type='submit' class="btn btn-success">Tambah</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>



<script>
  function tambah(){
    $('#modal_tambah').modal('show');
  }
</script>

<script>
  $(document).ready(function(){

    fetch('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json')
    .then(response => response.json())
    .then(provinces => {
      let options = "<option value=''>-- PILIH PROVINSI --</option>";
      provinces.forEach(function(item){
        options += "<option value='"+item.id+"'>"+item.name+"</option>";
      });

      $('#provinsi').html(options);
    });

  });


  $('#provinsi').change(function(){
    $('#provinsi_asli').val($(this).val());

    fetch('https://www.emsifa.com/api-wilayah-indonesia/api/regencies/'+$(this).val()+'.json')
    .then(response => response.json())
    .then(regencies => {
      let options = "<option value=''>-- PILIH KOTA --</option>";
      regencies.forEach(function(item){
        options += "<option value='"+item.id+"'>"+item.name+"</option>";
      });

      $('#kota').html(options);
    });

  });

  $('#kota').change(function(){
    $('#kota_asli').val($($(this)).val());
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/instalasi/index.blade.php ENDPATH**/ ?>