  <hr>
  <h3 style='text-align:center;'>Instalasi Kesehatan</h3>
  <div class="mb-3 col-md-6">
    <label class="form-label" for="provinsi">Provinsi</label>
    <input type="hidden" name="provinsi" id="provinsi_asli">
    <div class="position-relative">
      <select id="provinsi" class="select2 form-select select2-hidden-accessible" tabindex="-1" aria-hidden="true" style='width:100%;'>
        
      </select>
    </div>
  </div>
 
  <div class="mb-3 col-md-6">
    <label class="form-label" for="kota">Kota</label>
    <input type="hidden" name="kota" id="kota_asli">
    <div class="position-relative">
      <select id="kota" class="select2 form-select select2-hidden-accessible" tabindex="-1" aria-hidden="true" style='width:100%;'>
        
      </select>
    </div>
  </div>


  
  <script>
    $(document).ready(function(){

      fetch('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json')
      .then(response => response.json())
      .then(provinces => {
        let options = "<option value=''>-- PILIH PROVINSI --</option>";
        provinces.forEach(function(item){
          options += "<option value='"+item.id+"'>"+item.name+"</option>";
        });

        $('#provinsi').html(options);
      });

    });


    $('#provinsi').change(function(){
      $('#provinsi_asli').val($(this).val());

      fetch('https://www.emsifa.com/api-wilayah-indonesia/api/regencies/'+$(this).val()+'.json')
      .then(response => response.json())
      .then(regencies => {
        let options = "<option value=''>-- PILIH KOTA --</option>";
        regencies.forEach(function(item){
          options += "<option value='"+item.id+"'>"+item.name+"</option>";
        });

        $('#kota').html(options);
      });

    });

    $('#kota').change(function(){
      $('#kota_asli').val($($this).val());
    });
  </script><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/profil/instansi.blade.php ENDPATH**/ ?>