<!-- Menu -->

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <?php echo $__env->make('partials.sidebar_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    <li class="menu-item <?php echo e((url('/') == url()->current())? 'active' : ''); ?>">
      <a href="/" class="menu-link">
        
        <div data-i18n="Analytics">Dashboard</div>
      </a>
    </li>

    <!-- Permintaan Pasien -->
    <li class="menu-item <?php echo e(( strpos(url()->current(),'permintaan_menghubungkan') != FALSE )? 'active' : ''); ?>">
      <a href="/hubungan/permintaan_menghubungkan" class="menu-link">
        <div data-i18n="Analytics">Permintaan Menghubungkan</div>
      </a>
    </li>

    <!-- Pasien -->
    <li class="menu-item <?php echo e(( strpos(url()->current(),'pasien_saya') != FALSE )? 'active' : ''); ?>">
      <a href="/hubungan/pasien_saya" class="menu-link">
        <div data-i18n="Analytics">Pasien</div>
      </a>
    </li>

    <!-- Profil -->
    <li class="menu-item <?php echo e(( strpos(url()->current(),'profil') != FALSE )? 'active' : ''); ?>">
      <a href="/profil" class="menu-link">
        <div data-i18n="Analytics">Profil</div>
      </a>
    </li>

  </ul>
</aside>
<!-- / Menu --><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/partials/sidebar/tenaga_kesehatan_sidebar.blade.php ENDPATH**/ ?>