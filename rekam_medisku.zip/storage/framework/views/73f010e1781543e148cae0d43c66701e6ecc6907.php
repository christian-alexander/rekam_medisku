

<?php $__env->startSection('container'); ?>

  <div class="container mt-3">
    <div class="card mb-4">
      <h5 class="card-header">

        <?php if(auth()->user()->hasRole('tenaga_kesehatan')): ?>
          <a href="<?php echo e(url()->previous()); ?>">
            <i class='fa fa-arrow-left pe-3'></i>
          </a>
        <?php endif; ?>

        Rekam Medis <?php echo e(($tipe_rekam_medis == "tenaga_kesehatan")? 'dari Tenaga Kesehatan' : 'Personal'); ?> 
      </h5>
      <hr class="my-0">
      <div class="card-body pb-2">
        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-start align-items-sm-center gap-4">
            <?php if(auth()->user()->hasRole('pasien')): ?>  
              <img src="<?php echo e((auth()->user()->foto_profil == 'assets/img/avatars/user.png')? asset(auth()->user()->foto_profil) : asset('storage/'.auth()->user()->foto_profil)); ?>" alt="user-avatar" class="d-block rounded" height="100" width="100">
              <div class="button-wrapper">
                <h5><?php echo e(auth()->user()->nama); ?></h5>
                <p class="text-muted mb-0"><?php echo e((auth()->user()->jenis_kelamin == 1)? 'Laki laki' : 'Perempuan'); ?></p>                  
                <p class="text-muted mb-0"><?php echo e(Carbon::parse(auth()->user()->tanggal_lahir)->format('d M Y')); ?> ( <?php echo e(str_replace("yang lalu","",Carbon::parse(auth()->user()->tanggal_lahir)->diffForHumans())); ?>)</p>                  
                <p class="text-muted mb-0"><?php echo e(auth()->user()->no_hp); ?></p>                 
              </div>
            <?php else: ?>
              <img src="<?php echo e(($pasien->foto_profil == 'assets/img/avatars/user.png')? asset($pasien->foto_profil) : asset('storage/'.$pasien->foto_profil)); ?>" alt="user-avatar" class="d-block rounded" height="100" width="100">
              <div class="button-wrapper">
                <h5><?php echo e($pasien->nama); ?></h5>
                <p class="text-muted mb-0"><?php echo e(($pasien->jenis_kelamin == 1)? 'Laki laki' : 'Perempuan'); ?></p>                  
                <p class="text-muted mb-0"><?php echo e(Carbon::parse($pasien->tanggal_lahir)->format('d M Y')); ?> ( <?php echo e(str_replace("yang lalu","",Carbon::parse($pasien->tanggal_lahir)->diffForHumans())); ?>)</p>                  
                <p class="text-muted mb-0"><?php echo e($pasien->no_hp); ?></p>                  
              </div>
            <?php endif; ?>
          </div>

          <div class="col-lg-8 col-md-6 mt-3" style='border-left: 1px solid #d9dee3;'>
            <h5>Filter Diterapkan</h5>
            <hr>
            <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
              Tipe : <?php echo e(($filters['tipe_tenaga_kesehatan'] == 'all')? 'Semua Tipe' : (($filters['tipe_tenaga_kesehatan'] == 1)? 'Dokter' : 'Pengobat Tradisional')); ?>

              <br>
            <?php endif; ?>
            Periode : <?php echo e(Carbon::parse($filters['awal_tanggal'])->format('d M Y')); ?> - <?php echo e(Carbon::parse($filters['akhir_tanggal'])->format('d M Y')); ?>


          </div>


        </div>
        <hr>
      </div>


      <div class="card-body pt-0">          

        <form action="/rekam_medis/show_pdf" target="_blank" method="GET" style="display: inline;">
          <input type="hidden" name="pasien_id" value="<?php echo e($pasien_id); ?>">
          <input type="hidden" name="tipe_rekam_medis" value="<?php echo e($tipe_rekam_medis); ?>">
          <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
            <input type="hidden" name="tipe_tenaga_kesehatan" value="<?php echo e($filters['tipe_tenaga_kesehatan']); ?>">
          <?php endif; ?>
          <input type="hidden" name="awal_tanggal" value="<?php echo e($filters['awal_tanggal']); ?>">
          <input type="hidden" name="akhir_tanggal" value="<?php echo e($filters['akhir_tanggal']); ?>">
          <button type='submit' class='btn btn-secondary' style='margin-bottom:20px;'>Print</button>
        </form>
        <button class='btn btn-primary' style='margin-bottom:20px;' onclick="filter()">Filter</button>

        <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
          <?php if(auth()->user()->hasRole('tenaga_kesehatan')): ?>
            <button onclick="tambah()" class='btn btn-success' style='margin-bottom:20px;'>Tambah</button>                  
          <?php endif; ?>
        <?php else: ?>
          <?php if(auth()->user()->hasRole('pasien')): ?>
            <button onclick="tambah()" class='btn btn-success' style='margin-bottom:20px;'>Tambah</button>                  
          <?php endif; ?>
        <?php endif; ?>


        <div style='overflow:auto;'>
          <table class='table table-striped datatable' id='yajra'>
            <thead>
              <tr>
                <th style='width:20px;'>No</th>
                <th style='text-align:center;'>Tanggal</th>
                <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
                  <th style='text-align:center;'>Tenaga Kesehatan</th>
                <?php endif; ?>
                <th style='text-align:center;'>Anamnesa</th>
                <th style='text-align:center;'>Diagnosis</th>
                <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
                  <?php if(auth()->user()->hasRole('tenaga_kesehatan')): ?>
                    <th style='text-align:center;'>Edit</th>
                    <th style='text-align:center;'>Hapus</th>                    
                  <?php endif; ?>
                <?php else: ?>
                  <?php if(auth()->user()->hasRole('pasien')): ?>
                    <th style='text-align:center;'>Edit</th>
                    <th style='text-align:center;'>Hapus</th>                    
                  <?php endif; ?>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $rekam_medises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekam_medis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                <tr>
                  <td style='text-align:right'><?php echo e($loop->iteration); ?></td>
                  
                  <td style="text-align:center;">
                    <?php echo e(Carbon::parse($rekam_medis->tanggal)->format('d M Y')); ?>

                  </td>

                  <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
                    <td style="text-align:center;">
                      <?php echo e($rekam_medis->tenaga_kesehatan->nama); ?>

                      <hr>
                      <?php echo e(($rekam_medis->tenaga_kesehatan->tipe_tenaga_kesehatan == 1)? 'Dokter' : 'Pengobat Tradisional'); ?>

                    </td>
                  <?php endif; ?>
      
                  <td style="text-align: center;">
                    <?php echo e($rekam_medis->anamnesa); ?>

                  </td>
      
                  <td>
                    <span id='bacasedikit-<?php echo e($rekam_medis->id); ?>' style="display: block;">
                      <?php echo e(Str::limit($rekam_medis->diagnosis,100)); ?>

                      <?php if(strlen($rekam_medis->diagnosis) > 100): ?>
                        <button style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='baca_selengkapnya(<?php echo e($rekam_medis->id); ?>)'>
                          Baca Selengkapnya...
                        </button>
                      <?php endif; ?>
                    </span>
                    
                    <span id='bacalengkap-<?php echo e($rekam_medis->id); ?>' style="display: none;">
                      <?php echo e($rekam_medis->diagnosis); ?>

                      <button style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='baca_lebih_sedikit(<?php echo e($rekam_medis->id); ?>)'>
                        Baca Lebih Sedikit...
                      </button>
                    </span>
                  </td>

                  <?php if($tipe_rekam_medis == "tenaga_kesehatan"): ?>
                    <?php if(auth()->user()->hasRole('tenaga_kesehatan')): ?>
                      <td style="text-align: center;">
                        <button id='btn_edit' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='edit(<?php echo e($rekam_medis->id); ?>)'>
                          <i class='fa fa-edit' style='color:#3c8dbc;'></i>
                        </button>
                      </td>
          
                      <td style="text-align: center;">
                        <button id='btn_hapus' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='hapus(<?php echo e($rekam_medis->id); ?>)'>
                          <i class='fa fa-trash' style='color:#3c8dbc;'></i>
                        </button>
                      </td>
                    <?php endif; ?>
                  <?php else: ?>
                    <?php if(auth()->user()->hasRole('pasien')): ?>
                      <td style="text-align: center;">
                        <button id='btn_edit' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='edit(<?php echo e($rekam_medis->id); ?>)'>
                          <i class='fa fa-edit' style='color:#3c8dbc;'></i>
                        </button>
                      </td>
          
                      <td style="text-align: center;">
                        <button id='btn_hapus' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='hapus(<?php echo e($rekam_medis->id); ?>)'>
                          <i class='fa fa-trash' style='color:#3c8dbc;'></i>
                        </button>
                      </td>
                    <?php endif; ?>
                  <?php endif; ?>

                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
            </tbody>
          </table>
        </div>
    
      </div>
    
    </div>
  </div>


<div class="modal" id='modal_filter'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Filter Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="/rekam_medis/daftar_rekam_medis/<?php echo e(($tipe_rekam_medis == 'tenaga_kesehatan')? 'tenaga_kesehatan' : 'personal'); ?>/<?php echo e($pasien_id); ?>" method='GET' id='form_filter'>
          <input type="hidden" name="filtered" value="on">

          <?php if($tipe_rekam_medis == 'tenaga_kesehatan'): ?>
            <div class="mb-3">
              <label class="form-label">Tipe Tenaga Kesehatan</label>
              <div class="position-relative">
                <select name="tipe_tenaga_kesehatan" class='form-control' aria-hidden="true" style='width:100%;'>
                  <option value="all" selected>-- SEMUA TIPE --</option>
                  <option value="1">Dokter</option>
                  <option value="2">Pengobat Tradisional</option>
                </select>
              </div>
            </div>
          <?php endif; ?>
  

          <div class="mb-3">
            <label class="form-label">Awal Tanggal</label>
            <div class="position-relative">
              <input type="date" class="form-control" name="awal_tanggal" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Akhir Tanggal</label>
            <div class="position-relative">
              <input type="date" class="form-control" name="akhir_tanggal" required>
            </div>
          </div>

          <div class="form-group" style='text-align:center;'>
            <button type='submit' class="btn btn-primary">Filter</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal" id='modal_tambah'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="/rekam_medis" method='POST' id='form_tambah'>
          <?php echo csrf_field(); ?>

          <input type="hidden" name="pasien_id" value="<?php echo e($pasien_id); ?>">

          <div class="mb-3">
            <label class="form-label">Tanggal</label>
            <div class="position-relative">
              <input type="date" class="form-control" name="tanggal" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Anamnesa / Keluhan</label>
            <div class="position-relative">
              <input type="text" class="form-control" name="anamnesa" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Diagnosis</label>
            <div class="position-relative">
              <textarea class="form-control" name="diagnosis" style="height:150px;" required></textarea>
            </div>
          </div>

          <div class="form-group" style='text-align:center;'>
            <button type='submit' class="btn btn-success">Tambah</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal" id='modal_edit'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="diisi_dari_js" method='POST' id='form_edit'>
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="mb-3">
            <label class="form-label">Tanggal</label>
            <div class="position-relative">
              <input type="date" class="form-control" name="tanggal" id="tanggal_edit" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Anamnesa / Keluhan</label>
            <div class="position-relative">
              <input type="text" class="form-control" name="anamnesa" id='anamnesa_edit' required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Diagnosis</label>
            <div class="position-relative">
              <textarea class="form-control" name="diagnosis" id='diagnosis_edit' style="height:150px;" required></textarea>
            </div>
          </div>

          <div class="form-group" style='text-align:center;'>
            <button type='submit' class="btn btn-primary">Edit</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>




<div class="modal" id='modal_hapus'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Hapus Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Apakah anda yakin ingin hapus rekam medis ini?
      </div>
      <div class="modal-footer">
        <form action="diisi_dari_js" method='POST' id='form_hapus'>
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>

          <div class="form-group" style='text-align:center;'>
            <button type='submit' class="btn btn-danger">Hapus</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>

<script>
  function tambah(){
    $('#modal_tambah').modal('show');
  }
  
  function filter(){
    $('#modal_filter').modal('show');
  }

  function edit(id){
    $.ajax({
      url: "/rekam_medis/get_data/"+id
    })
    .done(function( data ){
      const rekam_medis = JSON.parse(data);

      $('#tanggal_edit').val(rekam_medis.tanggal);
      $('#anamnesa_edit').val(rekam_medis.anamnesa);
      $('#diagnosis_edit').val(rekam_medis.diagnosis);
    
      $('#form_edit').attr('action','/rekam_medis/'+id);
      $('#modal_edit').modal('show');
    });
  }

  function hapus(id){
    $('#form_hapus').attr('action','/rekam_medis/'+id);
    $('#modal_hapus').modal('show');
  }

  function baca_selengkapnya(id){
    $('#bacalengkap-'+id).css('display','block');
    $('#bacasedikit-'+id).css('display','none');
  }

  function baca_lebih_sedikit(id){
    $('#bacalengkap-'+id).css('display','none');
    $('#bacasedikit-'+id).css('display','block');
  }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/rekam_medis/daftar_rekam_medis.blade.php ENDPATH**/ ?>