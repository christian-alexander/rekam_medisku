

<?php $__env->startSection('container'); ?>

  <div class="container mt-3">
    <div class="card mb-4">
      <h5 class="card-header">Permintaan Menghubungkan</h5>
      <hr class="my-0">
      <div class="card-body">
        
        <div style='overflow:auto;'>
          <table class='table table-striped datatable'>
            <thead>
              <tr>
                <th style='width:20px;'>No</th>
                <th style='text-align:center;'>Foto</th>
                <th style='text-align:center;'>Nama</th>
                <th style='text-align:center;'>Terima</th>
                <th style='text-align:center;'>Tolak</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $hubungan_calon_pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hubungan_calon_pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                <tr>
                  <td style='text-align:right'><?php echo e($loop->iteration); ?></td>
                  
                  <td>
                    <div style='display:flex;'>
                      <div style='margin:0 auto;'>
                        <img src="<?php echo e(($hubungan_calon_pasien->pasien->foto_profil == 'assets/img/avatars/user.png')? asset($hubungan_calon_pasien->pasien->foto_profil) : asset('storage/'.$hubungan_calon_pasien->pasien->foto_profil)); ?>" alt="user-avatar" class="d-block rounded" height="100" width="100">
                      </div>
                    </div>
                  </td>

                  <td style="text-align: center;">
                    <?php echo e($hubungan_calon_pasien->pasien->nama); ?>

                  </td>
      
                  <td style="text-align: center;">
                    <button id='btn_terima' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='terima(<?php echo e($hubungan_calon_pasien->id); ?>)'>
                      <i class='fa fa-check' style='color:#3c8dbc;'></i>
                    </button>
                  </td>
      
                  <td style="text-align: center;">
                    <button id='btn_tolak' style='border:0;background-color:rgba(0,0,0,0);visibility:visible;' onclick='tolak(<?php echo e($hubungan_calon_pasien->id); ?>)'>
                      <i class='fa fa-times' style='color:#3c8dbc;'></i>
                    </button>
                  </td>
      
                </tr>
    
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            </tbody>
          </table>
        </div>
    
      </div>
    
    </div>
  </div>

  
  <div class="modal" id='modal_terima'>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Konfirmasi</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Apakah anda yakin ingin menerima?
          
        </div>

        <div class="modal-footer">
          <form action="diisi_dari_js" method='POST' id='form_terima'>
            <?php echo csrf_field(); ?>
  
            <div class="form-group" style='text-align:center;'>
              <button type='submit' class="btn btn-success">Terima</button>
            </div>
  
          </form>
        </div>
      </div>
    </div>
  </div>

  
  <div class="modal" id='modal_tolak'>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Konfirmasi</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Apakah anda yakin ingin menolak?
          
        </div>

        <div class="modal-footer">
          <form action="diisi_dari_js" method='POST' id='form_tolak'>
            <?php echo csrf_field(); ?>
  
            <div class="form-group" style='text-align:center;'>
              <button type='submit' class="btn btn-danger">Tolak</button>
            </div>
  
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
    function terima(id){
      $('#form_terima').attr('action','/hubungan/terima/'+id);
      $('#modal_terima').modal('show');
    }

    function tolak(id){
      $('#form_tolak').attr('action','/hubungan/tolak/'+id);
      $('#modal_tolak').modal('show');
    }
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/hubungan/permintaan.blade.php ENDPATH**/ ?>