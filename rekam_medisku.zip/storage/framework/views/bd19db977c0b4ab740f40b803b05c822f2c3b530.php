<!-- Menu -->

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <?php echo $__env->make('partials.sidebar_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    <li class="menu-item <?php echo e((url('/') == url()->current())? 'active' : ''); ?>">
      <a href="/" class="menu-link">
        
        <div data-i18n="Analytics">Dashboard</div>
      </a>
    </li>

    <!-- Akun -->
    <li class="menu-item <?php echo e(( strpos(url()->current(),'akun') != FALSE )? 'active' : ''); ?>">
      <a href="/akun" class="menu-link">
        
        <div data-i18n="Analytics">Akun</div>
      </a>
    </li>

    <!-- Faskes -->
    <li class="menu-item <?php echo e(( strpos(url()->current(),'faskes') != FALSE )? 'active' : ''); ?>">
      <a href="/faskes" class="menu-link">
        <div data-i18n="Analytics">Faskes</div>
      </a>
    </li>

  </ul>
</aside>
<!-- / Menu -->
<?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/partials/sidebar/admin_sidebar.blade.php ENDPATH**/ ?>