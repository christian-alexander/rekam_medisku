<div class="app-brand demo">
  <a href="#" class="app-brand-link">
    <img src="<?php echo e(asset('uwika.png')); ?>" alt="" style="max-width: 50px; max-height:50px;">
    <span class="app-brand-text demo menu-text fw-bolder ms-2" style="text-transform: none;"> UWIKA</span>
  </a>

  <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
    <i class="bx bx-chevron-left bx-sm align-middle"></i>
  </a>
</div><?php /**PATH C:\xampp\htdocs\spl\resources\views/partials/sidebar_logo.blade.php ENDPATH**/ ?>