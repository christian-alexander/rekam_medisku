<div class="mb-3 col-md-6 fv-plugins-icon-container">
  <label for="username" class="form-label">Bidang Spesialisasi</label>
  <br>
  <textarea name="spesialisasi" class='form-control' id="spesialisasi" cols="30" rows="10"></textarea>
<div class="fv-plugins-message-container invalid-feedback"></div></div>

<div class="mb-3 col-md-6 fv-plugins-icon-container">
  <label for="username" class="form-label">Bidang Spesialisasi</label>
  <br>
  <textarea name="spesialisasi" class='form-control' id="spesialisasi" cols="30" rows="10"></textarea>
<div class="fv-plugins-message-container invalid-feedback"></div></div>
<?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/profil/data_pelayan_kesehatan.blade.php ENDPATH**/ ?>