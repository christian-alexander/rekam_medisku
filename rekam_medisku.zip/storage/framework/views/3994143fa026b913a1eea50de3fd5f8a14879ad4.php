<div class="app-brand demo">
  <a href="#" class="app-brand-link">
    
    <span class="app-brand-text demo menu-text fw-bolder" style="text-transform: none;">Rekam Medisku</span>
  </a>

  <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
    <i class="bx bx-chevron-left bx-sm align-middle"></i>
  </a>
</div><?php /**PATH C:\xampp\htdocs\rekam_medisku\resources\views/partials/sidebar_logo.blade.php ENDPATH**/ ?>